#!/usr/bin/env python3
"""Скачивает фото интерьеров в images/."""
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "images"
root.mkdir(exist_ok=True)

# Unsplash: кадры в одной палитре (лён, шалфей, дерево, мягкий свет)
FILES = {
    "hero.jpg": "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1800&q=82",
    "hero-sofa.jpg": "https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=1400&q=82",
    "cat-sofas.jpg": "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=900&h=1200&q=80",
    "cat-chairs.jpg": "https://images.unsplash.com/photo-1598300042247-d088f8ab3a25?auto=format&fit=crop&w=900&h=1200&q=80",
    "cat-tables.jpg": "https://images.unsplash.com/photo-1577140917170-285929fb55b7?auto=format&fit=crop&w=900&h=1200&q=80",
    "cat-beds.jpg": "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&h=1200&q=80",
    "cat-storage.jpg": "https://images.unsplash.com/photo-1595428774223-ef52624120d1?auto=format&fit=crop&w=900&h=1200&q=80",
    "cat-light.jpg": "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=900&h=1200&q=80",
    "sofa-sage.jpg": "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sofa-linen.jpg": "https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sofa-graphite.jpg": "https://images.unsplash.com/photo-1540574163026-643ea20ade25?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sofa-ocean.jpg": "https://images.unsplash.com/photo-1567016432779-094069958ea5?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sofa-sand.jpg": "https://images.unsplash.com/photo-1484101403633-562f891dc89a?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sofa-clay.jpg": "https://images.unsplash.com/photo-1550226891-ef768dacebd0?auto=format&fit=crop&w=1100&h=1375&q=80",
    "chair.jpg": "https://images.unsplash.com/photo-1503602642458-232111445657?auto=format&fit=crop&w=1100&h=1375&q=80",
    "armchair.jpg": "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?auto=format&fit=crop&w=1100&h=1375&q=80",
    "barstool.jpg": "https://images.unsplash.com/photo-1501045661006-fcebe0257c3f?auto=format&fit=crop&w=1100&h=1375&q=80",
    "table-dining.jpg": "https://images.unsplash.com/photo-1617806118233-18e1de3d13f0?auto=format&fit=crop&w=1100&h=1375&q=80",
    "table-coffee.jpg": "https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?auto=format&fit=crop&w=1100&h=1375&q=80",
    "table-desk.jpg": "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=1100&h=1375&q=80",
    "bed.jpg": "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=1100&h=1375&q=80",
    "bed-soft.jpg": "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=1100&h=1375&q=80",
    "bed-kids.jpg": "https://images.unsplash.com/photo-1616594039964-b63b7ba40094?auto=format&fit=crop&w=1100&h=1375&q=80",
    "wardrobe.jpg": "https://images.unsplash.com/photo-1558997519-83ea9252edf8?auto=format&fit=crop&w=1100&h=1375&q=80",
    "dresser.jpg": "https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?auto=format&fit=crop&w=1100&h=1375&q=80",
    "tv.jpg": "https://images.unsplash.com/photo-1615874959474-d391bc80a04f?auto=format&fit=crop&w=1100&h=1375&q=80",
    "shelf.jpg": "https://images.unsplash.com/photo-1595428774076-89db85c2cde3?auto=format&fit=crop&w=1100&h=1375&q=80",
    "lamp-floor.jpg": "https://images.unsplash.com/photo-1543198126-a8ad8e47fb22?auto=format&fit=crop&w=1100&h=1375&q=80",
    "lamp-table.jpg": "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1100&h=1375&q=80",
    "chandelier.jpg": "https://images.unsplash.com/photo-1540932239986-30128078f3c5?auto=format&fit=crop&w=1100&h=1375&q=80",
    "sale.jpg": "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=80",
    "workshop.jpg": "https://images.unsplash.com/photo-1565793298595-6a381b3a7ff6?auto=format&fit=crop&w=1400&q=80",
    "showroom.jpg": "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1400&q=80",
    "ig1.jpg": "https://images.unsplash.com/photo-1616131168902-9bb73c1d3144?auto=format&fit=crop&w=800&h=800&q=80",
    "ig2.jpg": "https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&w=800&h=800&q=80",
    "ig3.jpg": "https://images.unsplash.com/photo-1583847268964-b283042f255a?auto=format&fit=crop&w=800&h=800&q=80",
    "ig4.jpg": "https://images.unsplash.com/photo-1600585154340-15c3a2b05832?auto=format&fit=crop&w=800&h=800&q=80",
    "ig5.jpg": "https://images.unsplash.com/photo-1616594039964-b63b7ba40094?auto=format&fit=crop&w=800&h=800&q=80",
    "ig6.jpg": "https://images.unsplash.com/photo-1615876234886-fd9a39fda97e?auto=format&fit=crop&w=800&h=800&q=80",
}

opener = urllib.request.build_opener()
opener.addheaders = [("User-Agent", "Mozilla/5.0 (compatible; MKMebel/1.0)")]
urllib.request.install_opener(opener)

ok, fail = 0, []
for name, url in FILES.items():
    dest = root / name
    if dest.exists() and dest.stat().st_size > 8000:
        print("skip", name)
        ok += 1
        continue
    try:
        urllib.request.urlretrieve(url, dest)
        size = dest.stat().st_size
        print(f"ok {name} {size}")
        if size < 4000:
            fail.append(name)
        else:
            ok += 1
    except Exception as e:
        print("fail", name, e)
        fail.append(name)
print(f"done ok={ok} fail={fail}")
