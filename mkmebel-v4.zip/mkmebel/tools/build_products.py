#!/usr/bin/env python3
"""Собирает js/products.js из data/products.csv и data/categories.csv.
Запуск: python3 tools/build_products.py  (из корня сайта)
Таблицу можно редактировать в Excel / Google Таблицах (сохранять как CSV UTF-8)."""
import csv, json, pathlib
root = pathlib.Path(__file__).resolve().parent.parent

def rows(name):
    text = (root / "data" / name).read_text(encoding="utf-8-sig")
    dialect = csv.Sniffer().sniff(text.splitlines()[0], delimiters=",;\t")
    return list(csv.DictReader(text.splitlines(), dialect=dialect))

cats = [{"id": r["id"], "name": r["name"], "c": [r["c1"], r["c2"]]} for r in rows("categories.csv")]
known = {c["id"] for c in cats}
num = lambda v: int(float(v)) if str(v).strip() else None
products = []
for r in rows("products.csv"):
    if not r.get("name", "").strip():
        continue
    if r["cat"] not in known:
        raise SystemExit(f"Товар {r['id']}: неизвестная категория «{r['cat']}»")
    products.append({"id": int(r["id"]), "cat": r["cat"], "name": r["name"].strip(),
        "price": num(r["price"]), "old": num(r["old"]), "tag": r["tag"].strip(), "img": r["img"].strip(),
        "desc": r["desc"].strip(), "mat": r["mat"].strip(), "color": r["color"].strip(),
        "w": num(r["w"]), "h": num(r["h"]), "d": num(r["d"]),
        "brand": r.get("brand","").strip(), "style": r.get("style","").strip(), "stock": r.get("stock","").strip(), "wt": num(r.get("wt",""))})
out = "// Файл создаётся автоматически: tools/build_products.py. Не правьте вручную, правьте data/*.csv\n"
out += "const CATEGORIES=" + json.dumps(cats, ensure_ascii=False) + ";\n"
out += "const PRODUCTS=" + json.dumps(products, ensure_ascii=False, separators=(",", ":")) + ";\n"
(root / "js" / "products.js").write_text(out, encoding="utf-8")
print(f"Готово: {len(products)} товаров, {len(cats)} категорий")
